package demo;


// action -> Method

public class Alien 
{
	
	public static void main(String[] args) 
	{
		
	}
}
