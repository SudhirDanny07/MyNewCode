package demo;

public class Calculator 
{

	public int add(int num1,int num2)
	{
		int r = num1 + num2;
		return r;	
		
	}
	public int sub(int num1,int num2)
	
	{
		int r = num1 - num2;
		return r;
	}
	
}
